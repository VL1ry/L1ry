from threading import Thread
from flask import Flask, request
import json
import v5path
from EGAM import EGAM
import requests

app = Flask("app")
ipath=v5path.ipath
ipath2=v5path.ipath2
ip2path=v5path.ip2path
BOTTOKEN=v5path.BOTTOKEN

CLIENT_ID = v5path.CLIENT_ID
CLIENT_SECRET = v5path.CLIENT_SECRET
REDIRECT_URI = v5path.REDIRECT_URI


headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:102.0) Gecko/20100101 Firefox/102.0',
    'Authorization': BOTTOKEN
}

egam=EGAM(bot_token=BOTTOKEN,client_id=CLIENT_ID,client_secret=CLIENT_SECRET,redirect_uri=REDIRECT_URI)
@app.route('/', methods=["GET"])
def index():
    try:
        code = request.args.get('code', '')
        if code == "":
          return
        if request.environ.get('HTTP_X_FORWARDED_FOR') is None:
          ip = request.environ['REMOTE_ADDR']
        else:
          ip = request.environ['HTTP_X_FORWARDED_FOR']
        
        
        state = request.args.get('state', '').split("=")
        serverstate=int(state[0],16)
        rolestate=int(state[1],8)
        try:
          serveridj = open(f"{ipath2}{serverstate}.json")
        except:
          return
        
        gettoken= egam.get_token(code)
        token = gettoken['access_token']
        getuser = egam.get_user(token)
        user = getuser["id"]
        name = getuser["username"]
        json_data = {
            'content': f"Discordユーザーネーム{name}さん (ID：{user})のIPアドレスは {ip} です"
        }
        requests.post(f"https://discord.com/api/v9/channels/{v5path.channelid}/messages", headers=headers, json=json_data)
        addrole=egam.add_role(user_id=user,guild_id=str(serverstate),role_id=str(rolestate))
        if not addrole==204:
          return f"<h1>ロールの付与に失敗しました<br>Botがロールを付与できる状態か確認してください<br>Botのロールが付与したいロールの1つ上に置かれていない場合や、管理権限に2段階認証が必要になっている場合ロールが付与できません！</h1>"

        serverid=json.load(serveridj)   
        useridj=open(ipath)
        userid = json.load(useridj)

        if not user in serverid.keys():
          serverid.update({user:f"{len(userid)}"})
          json.dump(serverid, open(f"{ipath2}{serverstate}.json","w"))     
      
        if not token in userid.values():
          userid.update({user:token})
          json.dump(userid, open(f"{ipath}","w"))
        
    except Exception as e:
        return f"<h1>エラー : {e}</h1>"

    return f"<h1>登録成功！ {name}さんよろしく！</h1>"

def run():
  app.run(debug=False,host="0.0.0.0")

def start():
  t = Thread(target=run)
  t.start()
