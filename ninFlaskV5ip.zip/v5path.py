BOTTOKEN="Botのトークンをここに"
CLIENT_ID = 'OAuth2のClientIDをここに'
CLIENT_SECRET = 'OAuth2のClientSecretをここに'
REDIRECT_URI = 'Flaskサーバーが建てられている場所(IPアドレスやドメイン)をここに'

ipath="userdata.json のパスをここに"
ipath2="サーバーID.json のフォルダーパスをここに"
authurl="作ったURLをここに"
webhook="WebHookのURL"